#!/bin/bash
#SBATCH --job-name="si.scf"
#SBATCH --output=job1.out
#SBATCH --error=job1.err
#SBATCH -n 20
#SBATCH --ntasks-per-node=88
#SBATCH --time=01:00:00
#SBATCH --qos="test"
#SBATCH --mail-user=
#SBATCH --mail-type=ALL

module load mkl/latest
module load mpi/latest

srun /opt/qe-6.6/bin/pw.x < si.scf.inp > si.scf.out
