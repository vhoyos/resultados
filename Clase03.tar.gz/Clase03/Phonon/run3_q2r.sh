#!/bin/bash
#SBATCH --job-name="si.q2r"
#SBATCH --output=job3.out
#SBATCH --error=job3.err
#SBATCH -n 20
#SBATCH --ntasks-per-node=88
#SBATCH --time=01:00:00
#SBATCH --qos="test"
#SBATCH --mail-user=
#SBATCH --mail-type=ALL

module load mkl/latest
module load mpi/latest

srun /opt/qe-6.6/bin/q2r.x < si.q2r.inp > si.q2r.out
